# 💰 Mis Finanzas · My Finances

Personal finance dashboard - standalone React app that runs entirely in the browser.
Upload your bank Excel statement and explore your money in seconds.

## ✨ Features

- 📥 **Import Excel** bank statements (.xls / .xlsx) — works with Spanish ING format and similar
- 🏷️ **Auto-categorization** of uncategorized transactions using keyword rules
- 📊 **Multiple charts**: pie chart, monthly bars, balance evolution line, category bars
- 🎯 **Monthly budgets** per category with alerts when you're close to the cap
- 🐷 **Savings goals** with progress tracking and deadlines
- 🔍 **Advanced filters**: date range, type, category, full-text search, quick presets
- 📤 **Export** to Excel or PDF (formatted report)
- 🌍 **i18n**: Spanish / English
- 💱 **Multi-currency**: EUR, USD, GBP, MXN, ARS, COP, BRL
- 🔒 **100% client-side** — everything stored in your browser (localStorage), no server, no tracking
- 📱 **Responsive** — works on desktop, tablet, mobile

## 🚀 Run locally

```bash
cd frontend
yarn install
yarn start
```

Open http://localhost:3000

## 🏗️ Build for production

```bash
yarn build
```

Outputs to `frontend/build/`. Serve as a static site.

## 📂 Project structure

```
frontend/
├── src/
│   ├── FinanzasApp.jsx      # Main app
│   ├── App.js               # Root component
│   ├── i18n.js              # ES/EN translations + currencies
│   ├── components/
│   │   ├── TopBar.jsx       # Header + language/currency selectors
│   │   ├── FileBar.jsx      # File chips
│   │   ├── Welcome.jsx      # Onboarding screen
│   │   ├── Filters.jsx      # Advanced filters
│   │   ├── KpiCards.jsx     # Income / expense / balance / savings rate
│   │   ├── Charts.jsx       # All charts (recharts)
│   │   ├── MovementsTable.jsx
│   │   ├── Budgets.jsx
│   │   └── Goals.jsx
│   └── utils/
│       ├── excel.js         # Excel parser + xlsx export
│       ├── pdf.js           # PDF report generator
│       ├── format.js        # Money & date formatters
│       ├── colors.js        # Category palette
│       ├── storage.js       # localStorage helpers
│       └── autoCategory.js  # Keyword-based auto-categorization
└── public/index.html
```

## 🎨 Tech

- React 19
- Tailwind CSS + custom warm theme
- recharts (charts)
- xlsx (Excel parsing + export)
- jspdf + jspdf-autotable (PDF export)
- lucide-react (icons)

## 📝 Excel format

The parser auto-detects headers. It looks for columns containing:
- **F. VALOR / FECHA / DATE** (date)
- **CATEGORÍA / CATEGORY** (category)
- **SUBCATEGORÍA / SUBCATEGORY** (subcategory)
- **DESCRIPCIÓN / DESCRIPTION / CONCEPTO** (description)
- **IMPORTE / AMOUNT / MONTO** (amount, negative = expense)
- **SALDO / BALANCE** (running balance)

Compatible with ING Spain exports out of the box.

---

Made with ❤️ — your data never leaves your browser.
