import { Wallet, Globe, Coins, Trash2 } from "lucide-react";
import { CURRENCIES, TRANSLATIONS } from "../i18n";

export default function TopBar({ lang, setLang, currency, setCurrency, onClearAll, hasData }) {
  const t = TRANSLATIONS[lang];
  return (
    <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16, marginBottom: 24 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 14,
          background: "linear-gradient(135deg, #FF9F43, #FF6B9D)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 6px 18px rgba(255,159,67,0.35)",
        }}>
          <Wallet size={26} color="#fff" strokeWidth={2.5} />
        </div>
        <div>
          <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, letterSpacing: "-0.02em" }} data-testid="app-title">
            {t.appTitle}
          </h1>
          <p style={{ margin: 0, fontSize: 13, color: "var(--text-soft)" }}>{t.appSubtitle}</p>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg-card)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "4px 4px 4px 10px" }}>
          <Globe size={15} color="var(--text-soft)" />
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value)}
            style={{ border: "none", background: "transparent", padding: "6px 4px", fontWeight: 600, fontSize: 13, width: "auto", boxShadow: "none" }}
            data-testid="language-select"
          >
            <option value="es">Español</option>
            <option value="en">English</option>
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg-card)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "4px 4px 4px 10px" }}>
          <Coins size={15} color="var(--text-soft)" />
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            style={{ border: "none", background: "transparent", padding: "6px 4px", fontWeight: 600, fontSize: 13, width: "auto", boxShadow: "none" }}
            data-testid="currency-select"
          >
            {Object.keys(CURRENCIES).map(c => (
              <option key={c} value={c}>{c} {CURRENCIES[c].symbol}</option>
            ))}
          </select>
        </div>

        {hasData && (
          <button
            className="btn btn-ghost btn-danger btn-sm"
            onClick={() => { if (window.confirm(t.confirmClearAll)) onClearAll(); }}
            data-testid="clear-all-btn"
            title={t.clearAll}
          >
            <Trash2 size={15} /> {t.clearAll}
          </button>
        )}
      </div>
    </header>
  );
}
